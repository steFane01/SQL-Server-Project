﻿CREATE DATABASE PJBD
ON PRIMARY
(
	NAME = pjbdData1,
   FILENAME = 'C:\Users\Gorella\Desktop\FAC\BazdeDeDate\[Gheorghe Stefan][C112E][Magazin Echipamente Audio]\PJBD.mdf',
   SIZE = 10MB,
   MAXSIZE = unlimited,
   FILEGROWTH = 5MB
),
(
	NAME = pjbdData2,
   FILENAME = 'C:\Users\Gorella\Desktop\FAC\BazdeDeDate\[Gheorghe Stefan][C112E][Magazin Echipamente Audio]\PJBD1.ndf',
   SIZE = 10MB,
   MAXSIZE = unlimited,
   FILEGROWTH = 5MB
),
(
	NAME = pjbdData3,
   FILENAME = 'C:\Users\Gorella\Desktop\FAC\BazdeDeDate\[Gheorghe Stefan][C112E][Magazin Echipamente Audio]\PJBD2.ndf',
   SIZE = 10MB,
   MAXSIZE = unlimited,
   FILEGROWTH = 5MB
)
LOG ON
(
	NAME = pjbdLog1,
   FILENAME = 'C:\Users\Gorella\Desktop\FAC\BazdeDeDate\[Gheorghe Stefan][C112E][Magazin Echipamente Audio]\PJBD1.ldf',
   SIZE = 10MB,
   MAXSIZE = unlimited,
   FILEGROWTH = 5MB
),
(
	NAME = pjbdLog2,
   FILENAME = 'C:\Users\Gorella\Desktop\FAC\BazdeDeDate\[Gheorghe Stefan][C112E][Magazin Echipamente Audio]\PJBD2.ldf',
   SIZE = 10MB,
   MAXSIZE = unlimited,
   FILEGROWTH = 5MB
);






--ALTER DATABASE pjbd
--ADD FILE (
--   NAME = ProiectBD,
--   FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\',
--   SIZE = unlimited,
--   MAXSIZE = 100MB,
--   FILEGROWTH = 5MB
--);


IF OBJECT_ID('Produse','U') IS NOT NULL
	DROP TABLE Produse
CREATE TABLE Produse(
	ID_produs INT identity(1,1) primary key,
	nume_produs VARCHAR(50) not null,
	descrier_produs varchar(200),
	pret_produs float not null,
	stoc_produs int,
	categorieID int foreign key references Categorii(ID_categorie),
	producatorID int foreign key references Producatori(ID_producator)
);
IF OBJECT_ID('Producatori','U') IS NOT NULL
	DROP TABLE Producatori
CREATE TABLE Producatori(
	ID_producator int identity(1,1) primary key, 
	nume_producator varchar(50) not null,
	tara_producator varchar(50) not null default 'Romania'
);
IF OBJECT_ID('Clienti','U') IS NOT NULL
	DROP TABLE Clienti
CREATE TABLE Clienti(
	ID_client int identity(1,1) primary key,
	nume_client varchar(50) not null,
	adresa_client varchar(50) not null,
	telefon_client varchar(10) not null,
	email_client varchar(30) not null
);
IF OBJECT_ID('Comenzi','U') IS NOT NULL
	DROP TABLE Comenzi
CREATE TABLE Comenzi(  
	ID_comanda int identity(1,1) primary key,
	data_comanda date not null,
	ID_client int foreign key references Clienti(ID_client),
	status_comanda varchar(30)
);
IF OBJECT_ID('Detalii_Comenzi','U') IS NOT NULL
	DROP TABLE Detalii_Comenzi
CREATE TABLE Detalii_Comenzi( 
	ID_comanda int foreign key references Comenzi(ID_comanda) not null,
	ID_produs int foreign key references Produse(ID_produs) not null,
	cantitate int not null
);
IF OBJECT_ID('Recenzii','U') IS NOT NULL
	DROP TABLE Recenzii
CREATE TABLE Recenzii( 
	ID_recenzie int identity(1,1) primary key,
	ID_produs int foreign key references Produse(ID_produs) not null,
	ID_client int foreign key references Clienti(ID_client) not null,
	rating int,
	comentariu varchar(200)
);
IF OBJECT_ID('Utilizatori','U') IS NOT NULL
	DROP TABLE Utilizatori
CREATE TABLE Utilizatori( 
	ID_utilizator int identity(1,1) primary key,
	nume_utilizator varchar(50) not null,
	parola_utilizator varchar(50) not null,
	rol_utilizator varchar(30) not null
);
IF OBJECT_ID('Categorii','U') IS NOT NULL
	DROP TABLE Categorii
CREATE TABLE Categorii(
	ID_categorie int identity(1,1) primary key,
	nume_categorie varchar(60) not null
);
IF OBJECT_ID('Companii_Transport','U') IS NOT NULL
	DROP TABLE Produse
CREATE TABLE Companii_Transport(
	ID_companie int identity(1,1) primary key,
	nume_companie varchar(50) not null,
	tarif_companie int not null
);
IF OBJECT_ID('Transporturi','U') IS NOT NULL
	DROP TABLE Transporturi
CREATE TABLE Transporturi(
	ID_transport int identity(1,1) primary key,
	ID_comanda int foreign key references Comenzi(ID_comanda) not null,
	ID_companie int foreign key references Companii_Transport(ID_companie) not null,
	data_livrare date not null
);

insert into Producatori(nume_producator,tara_producator)
values ('Pioneer','Romania'),
		('Yamaha','SUA'),
		('Harman Kardon','Germany');

insert into Categorii(nume_categorie)
values ('DJ'),
		('Studio'),
		('Instrumente muzicale');


insert into Produse(nume_produs,descrier_produs,pret_produs,stoc_produs, categorieID,producatorID)
values ('Pioneer DJ DDJ-400','Consola DJ',1500,50,1,1),
	('Pioneer DJ DDJ-FLX6-GT','Consola DJ',3299,35,1,1),
	('Neumann KH 120 A','Monitor activ studio',3099,43,3,3),
	('Mega Acoustic PMP 5 50 x 50 Grafit','Bureti acustici',29,500,3,3),
	('JET Guitars JL-500 SLB','Chitara electrica',1999,80,2,2),
	('TAMBURO T5 PLUS RED SPARKLE','Tobe',2619,25,2,2),
	('Beamz Fuze610Z','Moving-Head',2269,53,2,1),
	('Elation KL FRESNEL 8','Proiector teatru',5999,42,2,1),
	('Pioneer DJ DDJ-1000','Consola DJ',8990,35,1,1),
	('Subwoofer Yamaha','Subwoofer Bass',2990,53,2,2);

insert into Produse(nume_produs,descrier_produs,pret_produs,stoc_produs, categorieID,producatorID)
values ('TAMBURO T5 PLUS RED SPARKLE 2','Tobe',3099,0,2,2);

DBCC CHECKIDENT ('Produse', RESEED, 0);

delete from Produse
insert into Produse(nume_produs,descrier_produs,pret_produs,stoc_produs, categorieID,producatorID)
values ('TAMBURO T5 PLUS ULTRAWOW RED SPARKLE','Tobe',2619,0,2,2);


INSERT INTO Clienti (nume_client, adresa_client, telefon_client, email_client)
VALUES 
    ('Popescu Ion', 'Str. Mihai Viteazu, Nr. 10, Cluj-Napoca', '0751122334', 'ion.popescu@email.com'),
    ('Ionescu Maria', 'Str. Avram Iancu, Nr. 20, Timisoara', '0723112233', 'maria.ionescu@email.com'),
    ('Georgescu Andrei', 'Bd. Unirii, Nr. 15, Bucuresti', '0755100200', 'andrei.georgescu@email.com'),
    ('Popa Ana', 'Str. Victoriei, Nr. 25, Brasov', '0742112233', 'ana.popa@email.com'),
    ('Dumitrescu Bogdan', 'Bd. Dacia, Nr. 30, Iasi', '0734112233', 'bogdan.dumitrescu@email.com'),
    ('Munteanu Andrei', 'Str. Vasile Alecsandri, Nr. 18, Cluj-Napoca', '0755123456', 'andrei.munteanu@email.com'),
    ('Nistor Laura', 'Str. Lalelelor, Nr. 10, Timisoara', '0723112244', 'laura.nistor@email.com'),
    ('Moldovan Alexandru', 'Bd. Stefan cel Mare, Nr. 50, Bucuresti', '0755111222', 'alexandru.moldovan@email.com'),
    ('Popescu Andreea', 'Str. Plopilor, Nr. 15, Brasov', '0735112233', 'andreea.popescu@email.com'),
    ('Chiriac Andrei', 'Bd. Independentei, Nr. 10, Iasi', '0723999888', 'andrei.chiriac@email.com');

INSERT INTO Utilizatori (nume_utilizator, parola_utilizator, rol_utilizator)
VALUES 
('JohnDoe', 'password1', 'utilizator_standard'),
('JaneDoe', 'password2', 'utilizator_standard'),
('Admin1', 'password3', 'administrator'),
('User123', 'password4', 'utilizator_standard'),
('Admin2', 'password5', 'administrator');
INSERT INTO Utilizatori (nume_utilizator, parola_utilizator, rol_utilizator)
VALUES
('TestUser', 'password6', 'utilizator_standard'),
('CoolUser', 'password7', 'utilizator_standard'),
('SuperAdmin', 'password8', 'administrator'),
('UserX', 'password9', 'utilizator_standard'),
('Admin3', 'password10', 'administrator');

INSERT INTO Companii_Transport (nume_companie, tarif_companie) 
VALUES 
('DHL', 20), 
('UPS', 18),
('FedEx', 22),
('TNT', 16),
('DPD', 15);

INSERT INTO Comenzi (data_comanda, ID_client, status_comanda)
VALUES 
('2023-05-03', 1, 'in procesare'),
('2023-05-02', 2, 'in procesare'),
('2023-05-01', 3, 'livrata');
INSERT INTO Comenzi (data_comanda, ID_client, status_comanda)
VALUES
('2023-04-29', 4, 'livrata'),
('2023-04-28', 5, 'anulata'),
('2023-04-27', 6, 'in procesare'),
('2023-04-26', 7, 'in procesare'),
('2023-04-25', 8, 'in procesare'),
('2023-04-24', 9, 'livrata'),
('2023-04-23', 10, 'in procesare');

--sp_configure 'show advanced options', 1;
--GO
--RECONFIGURE;
--GO
--sp_configure 'Database Mail XPs', 1;
--GO
--RECONFIGURE;
--GO



ALTER TABLE Detalii_Comenzi
ADD firma_transport int FOREIGN KEY REFERENCES Companii_Transport(ID_companie);

delete from Detalii_Comenzi

INSERT INTO Detalii_Comenzi(ID_comanda, ID_produs, cantitate,firma_transport)
VALUES 
(1, 1, 2, 1),
(1, 3, 1, 3),
(1, 5, 3, 5),
(2, 2, 1, 3),
(2, 4, 2, 4);
INSERT INTO Detalii_Comenzi(ID_comanda, ID_produs, cantitate,firma_transport)
VALUES 
(2, 6, 1, 2),
(3, 1, 1, 2),
(3, 4, 2, 1),
(4, 2, 2, 3),
(5, 3, 1, 5);

delete from Recenzii

INSERT INTO Recenzii (ID_produs, ID_client, rating, comentariu)
VALUES
  (1, 1, 5, 'Foarte mulțumit de acest produs'),
  (2, 1, 4, 'Bună calitate, dar un pic prea scump'),
  (3, 2, 3, 'Nu sunt impresionat de acest produs'),
  (4, 2, 2, 'Nu recomand acest produs'),
  (5, 3, 5, 'Extraordinar! Recomand cu caldura!'),
  (6, 3, 4, 'Produsul este ok, dar a durat mult până a ajuns la mine'),
  (7, 4, 4, 'Sunt mulțumit de acest produs, îl folosesc în fiecare zi');
INSERT INTO Recenzii (ID_produs, ID_client, rating, comentariu)
VALUES
  (8, 4, 3, 'Produsul este ok, dar nu m-a impresionat cu adevărat'),
  (9, 5, 5, 'Produsul a ajuns la timp și este exact ceea ce am comandat'),
  (10, 5, 2, 'Nu sunt mulțumit de acest produs, nu funcționează corect');

INSERT INTO Transporturi (ID_comanda, ID_companie, data_livrare)
VALUES 
	(1, 1, '2023-05-07'),
	(2, 2, '2023-05-09'),
	(4, 3, '2023-05-10');

select * from Producatori
select * from Produse
select * from Categorii
select * from Clienti
select * from Comenzi
select * from Companii_Transport
select * from Detalii_Comenzi
select * from Recenzii
select * from Utilizatori
select * from Transporturi

----Select:
--1. 4 gruparea datelor.
--2. 4 filtrare de grup.
--3. 4 gruparea datelor filtrate.
--4. 4 cu folosirea de operatori pe seturi de date.
--5. 4 cu join-uri pe cel puțin 3 tabele



--Selecteaza numele, descrierea si pretul produselor cu pretul mai mare de 3000:
SELECT nume_produs, descrier_produs, pret_produs
FROM Produse
WHERE pret_produs > 3000;
--Selecteaza numele producatorilor si tara lor, ordonati alfabetic dupa tara:
SELECT nume_producator, tara_producator
FROM Producatori
ORDER BY tara_producator;
--Selecteaza numele si stocul produselor din categoria cu ID-ul 3 (Instrumente muzicale):
SELECT nume_produs, stoc_produs
FROM Produse
WHERE categorieID = 3;
--Selecteaza numele si pretul produselor care sunt din categoria 'DJ' sau 'Studio':
SELECT nume_produs, pret_produs
FROM Produse
WHERE categorieID IN (
	SELECT ID_categorie
	FROM Categorii
	WHERE nume_categorie IN ('DJ', 'Studio')
);
--Selecteaza numele clientilor si adresa lor:
SELECT nume_client, adresa_client
FROM Clienti;
--Selecteaza numele si ratingul produselor care au cel putin o recenzie:
SELECT p.nume_produs, r.rating
FROM Produse p
JOIN Recenzii r ON p.ID_produs = r.ID_produs;
--Selecteaza numele si numarul de comenzi ale clientilor care au plasat cel putin o comanda:
SELECT c.nume_client, COUNT(*) AS numar_comenzi
FROM Clienti c
JOIN Comenzi co ON c.ID_client = co.ID_client
GROUP BY c.nume_client;
--Selecteaza numele si pretul produselor care sunt produse de producatorul 'Yamaha':
SELECT nume_produs, pret_produs
FROM Produse
WHERE producatorID = (
	SELECT ID_producator
	FROM Producatori
	WHERE nume_producator = 'Yamaha'
);
--Selecteaza numele si numarul de produse din fiecare categorie:
SELECT c.nume_categorie, COUNT(*) AS numar_produse
FROM Categorii c
JOIN Produse p ON c.ID_categorie = p.categorieID
GROUP BY c.nume_categorie;
--Selecteaza numele si tariful companiilor de transport:
SELECT nume_companie, tarif_companie
FROM Companii_Transport;






--Afiseaza toate produsele care au un pret mai mic decat 2000:
SELECT * FROM Produse
WHERE pret_produs < 2000;
--Afiseaza toate produsele care sunt in stoc:
SELECT * FROM Produse
WHERE stoc_produs > 0;
--Afiseaza toate categoriile disponibile:
SELECT * FROM Categorii;
--Afiseaza toti clientii care au plasat o comanda:
SELECT DISTINCT c.*
FROM Clienti c
JOIN Comenzi cm ON c.ID_client = cm.ID_client;
--Afiseaza toate recenziile lasate de clientii cu numele "Popescu":
SELECT r.*
FROM Recenzii r
JOIN Clienti c ON r.ID_client = c.ID_client
WHERE c.nume_client LIKE 'Popescu%';
--Afiseaza toate comenzile plasate inainte de data de 2022-01-01:
SELECT * FROM Comenzi
WHERE data_comanda < '2023-05-05';
--Afiseaza toate detaliile comenzilor
--care contin produse de la producatorul cu numele "Pioneer":
SELECT dc.*
FROM Detalii_Comenzi dc
JOIN Produse p ON dc.ID_produs = p.ID_produs
JOIN Producatori pr ON p.producatorID = pr.ID_producator
WHERE pr.nume_producator = 'Pioneer';
--Afiseaza numele clientilor si adresele lor 
--care au comandat produse de la producatorul cu numele "Yamaha":
SELECT DISTINCT c.nume_client, c.adresa_client
FROM Clienti c
JOIN Comenzi cm ON c.ID_client = cm.ID_client
JOIN Detalii_Comenzi dc ON cm.ID_comanda = dc.ID_comanda
JOIN Produse p ON dc.ID_produs = p.ID_produs
JOIN Producatori pr ON p.producatorID = pr.ID_producator
WHERE pr.nume_producator = 'Yamaha';
--Afiseaza numele si pretul tuturor produselor din categoria "DJ":
SELECT nume_produs, pret_produs
FROM Produse p
JOIN Categorii c ON p.categorieID = c.ID_categorie
WHERE c.nume_categorie = 'DJ';
--Afiseaza numele si rating-ul tuturor produselor care au cel putin o recenzie:
SELECT p.nume_produs, r.rating
FROM Produse p
JOIN Recenzii r ON p.ID_produs = r.ID_produs;




--Afisati numarul total de produse din fiecare categorie:
SELECT Categorii.nume_categorie, COUNT(*) AS 'Numar Produse'
FROM Produse
INNER JOIN Categorii ON Produse.categorieID = Categorii.ID_categorie
GROUP BY Categorii.nume_categorie;
--Calculeaza media preturilor produselor pentru fiecare producator:
SELECT Producatori.nume_producator, AVG(Produse.pret_produs) AS 'Media Preturilor'
FROM Produse
INNER JOIN Producatori ON Produse.producatorID = Producatori.ID_producator
GROUP BY Producatori.nume_producator;
--Calculeaza numarul total de comenzi plasate de fiecare client:
SELECT Clienti.nume_client, COUNT(*) AS 'Numar Comenzi'
FROM Comenzi
INNER JOIN Clienti ON Comenzi.ID_client = Clienti.ID_client
GROUP BY Clienti.nume_client;
--Calculeaza valoarea totala a stocului pentru fiecare categorie de produse:
SELECT Categorii.nume_categorie, SUM(Produse.stoc_produs * Produse.pret_produs) AS 'Valoare Stoc'
FROM Produse
INNER JOIN Categorii ON Produse.categorieID = Categorii.ID_categorie
GROUP BY Categorii.nume_categorie;



--Selectați numele producătorilor și numărul de produse din fiecare categorie pe care îl produc:
SELECT P.nume_producator, C.nume_categorie, COUNT(*) as numar_produse
FROM Produse PR
INNER JOIN Categorii C ON PR.categorieID = C.ID_categorie
INNER JOIN Producatori P ON PR.producatorID = P.ID_producator
GROUP BY P.nume_producator, C.nume_categorie
--Selectați numele categoriilor și numărul de produse disponibile în fiecare categorie,
--unde stoc_produs este mai mare decât 0:
SELECT C.nume_categorie, COUNT(*) as numar_produse_disponibile
FROM Produse PR
INNER JOIN Categorii C ON PR.categorieID = C.ID_categorie
WHERE PR.stoc_produs > 0
GROUP BY C.nume_categorie
--Selectați numele clienților și numărul de comenzi pe care le-au făcut,
--ordonate descrescător după numărul de comenzi:
SELECT Cl.nume_client, COUNT(*) as numar_comenzi
FROM Comenzi Co
INNER JOIN Clienti Cl ON Co.ID_client = Cl.ID_client
GROUP BY Cl.nume_client
ORDER BY numar_comenzi DESC
--Selectați numele companiilor de transport și numărul de comenzi pe care le-au livrat,
--ordonate descrescător după numărul de comenzi:
SELECT CT.nume_companie, COUNT(*) as numar_comenzi_livrate
FROM Transporturi T
INNER JOIN Companii_Transport CT ON T.ID_companie = CT.ID_companie
GROUP BY CT.nume_companie
ORDER BY numar_comenzi_livrate DESC



--Să se afișeze numele producătorilor și numărul de produse pe care le au în tabelul "Produse":
SELECT P.nume_producator, COUNT(*) AS 'Numar produse'
FROM Produse AS PR
INNER JOIN Producatori AS P ON PR.producatorID = P.ID_producator
GROUP BY P.nume_producator;
--Să se afișeze numele categoriilor și prețul maxim al produselor din fiecare categorie:
SELECT C.nume_categorie, MAX(P.pret_produs) AS 'Pret maxim'
FROM Produse AS P
INNER JOIN Categorii AS C ON P.categorieID = C.ID_categorie
GROUP BY C.nume_categorie;
--Să se afișeze numele categoriilor și numărul de produse disponibile în fiecare categorie,
--ordonate descrescător după numărul de produse disponibile:
SELECT C.nume_categorie, COUNT(*) AS 'Numar produse'
FROM Produse AS P
INNER JOIN Categorii AS C ON P.categorieID = C.ID_categorie
WHERE P.stoc_produs > 0
GROUP BY C.nume_categorie
ORDER BY COUNT(*) DESC;
--Să se afișeze numele producătorilor și prețul mediu al produselor lor,
--ordonate crescător după prețul mediu:
SELECT P.nume_producator, AVG(PR.pret_produs) AS 'Pret mediu'
FROM Produse AS PR
INNER JOIN Producatori AS P ON PR.producatorID = P.ID_producator
GROUP BY P.nume_producator
ORDER BY AVG(PR.pret_produs) ASC;



--Găsirea produselor care nu au nicio recenzie:
SELECT *FROM Produse
WHERE ID_produs NOT IN (SELECT ID_produs FROM Recenzii)
--Găsirea categoriilor de produse care nu au niciun produs în stoc:
SELECT *FROM Categorii
WHERE ID_categorie NOT IN (SELECT categorieID FROM Produse WHERE stoc_produs > 0)
--Găsirea clienților care au plasat cel puțin o comandă și au făcut cel puțin o recenzie:
SELECT *FROM Clienti
WHERE ID_client IN (SELECT ID_client FROM Comenzi) AND ID_client IN (SELECT ID_client FROM Recenzii)
--Găsirea producătorilor care au produse,
--cu prețul mai mare decât media prețurilor produselor din aceeași categorie:
SELECT *FROM Producatori
WHERE ID_producator IN (SELECT producatorID FROM Produse WHERE pret_produs > (SELECT AVG(pret_produs) FROM Produse WHERE categorieID = Produse.categorieID))

--Gasirea produselor care nu au recenzii
SELECT * FROM Produse
WHERE ID_produs NOT IN (SELECT ID_produs FROM Detalii_Comenzi)


--Selectarea tuturor produselor dintr-o anumita categorie,
--impreuna cu numele producatorului si numele categoriei:
SELECT Produse.nume_produs, Producatori.nume_producator, Categorii.nume_categorie
FROM Produse
JOIN Producatori ON Produse.producatorID = Producatori.ID_producator
JOIN Categorii ON Produse.categorieID = Categorii.ID_categorie
WHERE Categorii.nume_categorie = 'Studio'
--Selectarea numelor si datelor comenzilor efectuate de un anumit client,
--impreuna cu produsele comandate si cantitatea lor:
SELECT Clienti.nume_client, Comenzi.data_comanda, Produse.nume_produs, Detalii_Comenzi.cantitate
FROM Clienti
JOIN Comenzi ON Clienti.ID_client = Comenzi.ID_client
JOIN Detalii_Comenzi ON Comenzi.ID_comanda = Detalii_Comenzi.ID_comanda
JOIN Produse ON Detalii_Comenzi.ID_produs = Produse.ID_produs
WHERE Clienti.nume_client = 'Popa Ana'
--Selectarea rating-ului si comentariului asociat unui produs,
--impreuna cu numele clientului care a lasat recenzia:
SELECT Recenzii.rating, Recenzii.comentariu, Clienti.nume_client
FROM Recenzii
JOIN Clienti ON Recenzii.ID_client = Clienti.ID_client
WHERE Recenzii.ID_produs = 5
--Selectarea tuturor produselor cu un anumit pret si care au fost comandate intr-o anumita zi,
--impreuna cu numele companiei de transport si numele clientului care a facut comanda:
SELECT Produse.nume_produs, Companii_Transport.nume_companie, Clienti.nume_client
FROM Produse
JOIN Detalii_Comenzi ON Produse.ID_produs = Detalii_Comenzi.ID_produs
JOIN Comenzi ON Detalii_Comenzi.ID_comanda = Comenzi.ID_comanda
JOIN Transporturi ON Comenzi.ID_comanda = Transporturi.ID_comanda
JOIN Companii_Transport ON Transporturi.ID_companie = Companii_Transport.ID_companie
JOIN Clienti ON Comenzi.ID_client = Clienti.ID_client
WHERE Produse.pret_produs = 3099 AND Comenzi.data_comanda = '2023-05-03'

select * from Produse

select * from Comenzi
select * from Detalii_Comenzi
select * from Produse

--UPDATES

--Sa se actualizeze numele producatorului pentru produsul cu ID-ul 3 in "Harman Kardon".
UPDATE Produse
SET producatorID = (SELECT ID_producator FROM Producatori WHERE nume_producator = 'Harman Kardon')
WHERE ID_produs = 3
--Sa se modifice pretul produsului cu ID-ul 8 la 6499.
UPDATE Produse
SET pret_produs = 6499
WHERE ID_produs = 8
--Sa se modifice statusul comenzii cu ID-ul 2 la "Livrata":
UPDATE Comenzi
SET status_comanda = 'Livrata'
WHERE ID_comanda = 2
--Sa se modifice numele utilizatorului cu ID-ul 4 la "AnaPopa":
UPDATE Utilizatori
SET nume_utilizator = 'AnaPopa'
WHERE ID_utilizator = 4
--Sa se modifice tara de provenienta a producatorului cu ID-ul 1 la "Franta":
UPDATE Producatori
SET tara_producator = 'Franta'
WHERE ID_producator = 1

select * from Produse



--Modificarea prețului produsului cu ID-ul 1 la 50.99:
UPDATE Produse
SET pret_produs = 50.99
WHERE ID_produs = 1;
--Modificarea adresei clientului cu ID-ul 5 la "Str. Crinului, nr. 10":
UPDATE Clienti
SET adresa_client = 'Str. Crinului, nr. 10'
WHERE ID_client = 5;
--Actualizarea categoriei produsului cu ID-ul 3 la o altă categorie:
UPDATE Produse
SET categorieID = 2
WHERE ID_produs = 3;
--Modificarea statusului comenzii cu ID-ul 7 la "În livrare":
UPDATE Comenzi
SET status_comanda = 'În livrare'
WHERE ID_comanda = 7;
--Actualizarea rating-ului recenziei cu ID-ul 4 la 4:
UPDATE Recenzii
SET rating = 4
WHERE ID_recenzie = 4;
--Modifică prețul produsului cu ID-ul 7 la 125.50:
UPDATE Produse
SET pret_produs = 125.50
WHERE ID_produs = 7;
--Actualizează stocul produsului cu ID-ul 3 adăugând 50 de unități la stocul curent:
UPDATE Produse
SET stoc_produs = stoc_produs + 50
WHERE ID_produs = 3;
--Modifică data unei comenzi cu ID-ul 23 la data de 2023-05-15:
UPDATE Comenzi
SET data_comanda = '2023-05-15'
WHERE ID_comanda = 23;
--Actualizează țara producătorului cu ID-ul 8 la "Germania":
UPDATE Producatori
SET tara_producator = 'Germania'
WHERE ID_producator = 8;
--Modifică rating-ul și comentariul unei recenzii cu ID-ul 4:
UPDATE Recenzii
SET rating = 4,
    comentariu = 'Produsul este foarte bun, dar am avut probleme cu livrarea.'
WHERE ID_recenzie = 4;
--Modifică rating-ul și comentariul unei recenzii cu ID-ul 8:
UPDATE Recenzii
SET rating = 3,
    comentariu = 'Recomand cu caldura!'
WHERE ID_recenzie = 12;

--Modifică data unei comenzi cu ID-ul 9 la data de 2022-04-15:
UPDATE Comenzi
SET data_comanda = '2022-04-15'
WHERE ID_comanda = 9;

--Setarea unui preț nou pentru un produs și actualizarea stocului disponibil,
--apoi actualizarea detaliilor comenzii corespunzătoare cu aceste modificări:
UPDATE Produse
SET pret_produs = 99.99, stoc_produs = stoc_produs - 1
FROM Produse
JOIN Categorii ON Produse.categorieID = Categorii.ID_categorie
JOIN Detalii_Comenzi ON Produse.ID_produs = Detalii_Comenzi.ID_produs
JOIN Comenzi ON Detalii_Comenzi.ID_comanda = Comenzi.ID_comanda
WHERE Categorii.nume_categorie = 'Electronice'
AND Comenzi.status_comanda = 'In curs de livrare'
AND Comenzi.data_comanda >= '2023-01-01'
AND Produse.nume_produs = 'Laptop ASUS ZenBook';
--Actualizarea țării de proveniență pentru un producător și
--actualizarea companiilor de transport care livrează comenzi cu produse din această țară:
UPDATE Producatori
SET tara_producator = 'Germania'
FROM Producatori
JOIN Produse ON Producatori.ID_producator = Produse.producatorID
JOIN Detalii_Comenzi ON Produse.ID_produs = Detalii_Comenzi.ID_produs
JOIN Comenzi ON Detalii_Comenzi.ID_comanda = Comenzi.ID_comanda
JOIN Companii_Transport ON Comenzi.ID_comanda = Transporturi.ID_comanda
WHERE Producatori.nume_producator = 'Samsung'
AND Companii_Transport.nume_companie = 'DHL'
AND Comenzi.status_comanda = 'In curs de livrare'
AND Transporturi.data_livrare > '2023-05-07';
--Actualizarea adresei de livrare pentru un client și
--actualizarea detaliilor transporturilor corespunzătoare:
UPDATE Clienti
SET adresa_client = 'Str. Bucuresti Nr. 1, Bl. A, Sc. B, Ap. 3'
FROM Clienti
JOIN Comenzi ON Clienti.ID_client = Comenzi.ID_client
JOIN Transporturi ON Comenzi.ID_comanda = Transporturi.ID_comanda
JOIN Companii_Transport ON Transporturi.ID_companie = Companii_Transport.ID_companie
WHERE Companii_Transport.nume_companie = 'Fan Courier'
AND Comenzi.status_comanda = 'Plasata'
AND Transporturi.data_livrare > '2023-05-10'
AND Clienti.nume_client = 'Popescu Ion';
--Actualizarea rating-ului și comentariului asociate unei recenzii și
--actualizarea numărului total de recenzii pentru produsul corespunzător:
UPDATE Recenzii
SET rating = 4, comentariu = 'Produsul a fost bine ambalat și livrat la timp.'
FROM Recenzii
JOIN Produse ON Recenzii.ID_produs = Produse.ID_produs
JOIN Categorii ON Produse.categorieID = Categorii.ID_categorie



----CTE's



--Extragerea numelui si adresei tuturor clientilor care au plasat cel putin o comanda
--si nu au scris nicio recenzie.
WITH Comenzi_Clienti AS (
    SELECT DISTINCT c.nume_client, c.adresa_client
    FROM Clienti c
    INNER JOIN Comenzi co ON c.ID_client = co.ID_client
    LEFT JOIN Recenzii r ON c.ID_client = r.ID_client
    WHERE r.ID_client IS NULL
)
SELECT cc.nume_client, cc.adresa_client
FROM Comenzi_Clienti cc;



--Să se afișeze numele producătorilor, împreună cu numărul de produse pe care le au în ofertă,
--ordonate descrescător după numărul de produse.
WITH NrProduse AS (
  SELECT producatorID, COUNT(*) AS NrProduse
  FROM Produse
  GROUP BY producatorID
)
SELECT P.nume_producator, ISNULL(N.NrProduse, 0) AS NrProduse
FROM Producatori AS P
LEFT JOIN NrProduse AS N ON P.ID_producator = N.producatorID
ORDER BY ISNULL(N.NrProduse, 0) DESC;
--Să se afișeze numele clienților care au plasat cel puțin o comandă în ultimele 30 de zile.
WITH ComenziRecente AS (
  SELECT ID_client
  FROM Comenzi
  WHERE data_comanda >= DATEADD(day, -30, GETDATE())
  GROUP BY ID_client
)
SELECT nume_client
FROM Clienti
WHERE ID_client IN (SELECT ID_client FROM ComenziRecente);
--Să se afișeze numele produselor care nu sunt în stoc.
WITH ProduseOutOfStock AS (
  SELECT *
  FROM Produse
  WHERE stoc_produs = 0
)
SELECT nume_produs
FROM ProduseOutOfStock;
--Să se afișeze numele clienților care au comenzi în stadiul "în livrare",
--împreună cu data estimată de livrare și tariful companiei de transport folosite.
WITH ComenziInLivrare AS (
  SELECT ID_client, ID_transport
  FROM Comenzi
  WHERE status_comanda = 'în livrare'
)
SELECT C.nume_client, T.data_livrare, CT.tarif_companie
FROM ComenziInLivrare AS CIL
INNER JOIN Clienti AS C ON CIL.ID_client = C.ID_client
INNER JOIN Transporturi AS T ON CIL.ID_transport = T.ID_transport
INNER JOIN Companii_Transport AS CT ON T.ID_companie = CT.ID_companie;
--Să se afișeze numele produselor,
--împreună cu media rating-urilor lor și numărul total de recenzii.
WITH Ratings AS (
  SELECT ID_produs, AVG(rating) AS MediaRating, COUNT(*) AS NrRecenzii
  FROM Recenzii
  GROUP BY ID_produs
)
SELECT P.nume_produs, ISNULL(R.MediaRating, 0) AS MediaRating, ISNULL(R.NrRecenzii, 0) AS NrRecenzii
FROM Produse AS P
LEFT JOIN Ratings AS R ON P.ID_produs = R.ID_produs;

--Sa se afiseze produsul cu cel mai mare pret din fiecare categorie
WITH CTE AS (
    SELECT 
        c.nume_categorie, 
        p.nume_produs, 
        p.pret_produs, 
        ROW_NUMBER() OVER (PARTITION BY c.nume_categorie ORDER BY p.pret_produs DESC) AS RN
    FROM 
        Categorii c 
        JOIN Produse p ON c.ID_categorie = p.categorieID
)
SELECT 
    CTE.nume_categorie, 
    CTE.nume_produs, 
    CTE.pret_produs
FROM 
    CTE 
WHERE 
    CTE.RN = 1;



----Tranzactii cu operatii DML si mecanisme de gestionare a erorilor



--Adaugare comanda in tabela "Comenzi":
BEGIN TRANSACTION
INSERT INTO Comenzi (data_comanda, ID_client, status_comanda)
VALUES ('2023-05-10', 3, 'In procesare')
COMMIT TRANSACTION

--Actualizare stoc produse si adaugare in tabela "Detalii_Comenzi":
BEGIN TRANSACTION
UPDATE Produse
SET stoc_produs = stoc_produs - 1
WHERE ID_produs = 1

INSERT INTO Detalii_Comenzi (ID_comanda, ID_produs, cantitate)
VALUES (1, 1, 1)
COMMIT TRANSACTION





--Actualizarea pretului unui produs si modificarea stocului
BEGIN TRY
	BEGIN TRANSACTION
		UPDATE Produse SET pret_produs = 1600 WHERE ID_produs = 1
		UPDATE Produse SET stoc_produs = 45 WHERE ID_produs = 1
		INSERT INTO Detalii_Comenzi (ID_comanda, ID_produs, cantitate) VALUES (1, 1, 5)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION
	PRINT 'A aparut o eroare: ' + ERROR_MESSAGE()
END CATCH
--Adaugarea unei noi comenzi si a detaliilor acesteia
BEGIN TRY
	BEGIN TRANSACTION
		INSERT INTO Comenzi (data_comanda, ID_client, status_comanda) VALUES ('2023-05-08', 2, 'noua')
		DECLARE @id_comanda int = SCOPE_IDENTITY()
		INSERT INTO Detalii_Comenzi (ID_comanda, ID_produs, cantitate) VALUES (@id_comanda, 2, 2)
		INSERT INTO Detalii_Comenzi (ID_comanda, ID_produs, cantitate) VALUES (@id_comanda, 4, 4)
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION
	PRINT 'A aparut o eroare: ' + ERROR_MESSAGE()
END CATCH
--Stergerea unui produs si a detaliilor comenzilor care il contin
BEGIN TRY
	BEGIN TRANSACTION
		DELETE FROM Detalii_Comenzi WHERE ID_produs = 5
		DELETE FROM Produse WHERE ID_produs = 5
		UPDATE Produse SET stoc_produs = stoc_produs - 10 WHERE ID_produs = 1
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION
	PRINT 'A aparut o eroare: ' + ERROR_MESSAGE()
END CATCH
--Inserare in tabela Recenzii a unei recenzii noi de la clientul cu numele Popescu Ion pentru produsul cu ID_produs = 4,
--cu rating = 4 si comentariu = "Sunt foarte multumit de acest monitor de studio!"
BEGIN TRY
	INSERT INTO Recenzii (ID_produs, ID_client, rating, comentariu)
	VALUES (4, (SELECT ID_client FROM Clienti WHERE nume_client = 'Popescu Ion'), 4, 'Sunt foarte multumit de acest monitor de studio!')
END TRY
BEGIN CATCH
	PRINT 'A aparut o eroare: ' + ERROR_MESSAGE()
END CATCH;
--Stergere din tabela Produse a produsului cu ID_produs = 8, daca acesta exista.
BEGIN TRY
	DELETE FROM Produse WHERE ID_produs = 8;
END TRY
BEGIN CATCH
	PRINT 'A aparut o eroare: ' + ERROR_MESSAGE()
END CATCH;
--Actualizare in tabela Comenzi a statusului comenzii cu ID_comanda = 2, la status_comanda = 'In livrare'.
BEGIN TRY
	UPDATE Comenzi SET status_comanda = 'In livrare' WHERE ID_comanda = 2;
END TRY
BEGIN CATCH
	PRINT 'A aparut o eroare: ' + ERROR_MESSAGE()
END CATCH;
--Actualizarea prețului unui produs și înregistrarea în tabelul de recenzii
BEGIN TRANSACTION;

DECLARE @id_produs int = 5;
DECLARE @noul_pret float = 1899;

BEGIN TRY
    UPDATE Produse
    SET pret_produs = @noul_pret
    WHERE ID_produs = @id_produs;

    INSERT INTO Recenzii (ID_produs, ID_client, rating, comentariu)
    VALUES (@id_produs, 3, 4, 'Produsul este excelent!');

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Tranzacția a fost anulată. A apărut o eroare: ' + ERROR_MESSAGE();
END CATCH
--Inregistrarea unei comenzi pentru un client și actualizarea stocului de produse
BEGIN TRANSACTION;

DECLARE @id_client int = 1;

BEGIN TRY
    INSERT INTO Comenzi (data_comanda, ID_client, status_comanda)
    VALUES (GETDATE(), @id_client, 'In procesare');

    DECLARE @id_comand2 int = SCOPE_IDENTITY();

    INSERT INTO Detalii_Comenzi (ID_comanda, ID_produs, cantitate)
    VALUES (@id_comand2, 9, 1);

    UPDATE Produse
    SET stoc_produs = stoc_produs - 1
    WHERE ID_produs = 9;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Tranzacția a fost anulată. A apărut o eroare: ' + ERROR_MESSAGE();
END CATCH
--Stergerea unui client și a tuturor comenzilor sale
BEGIN TRANSACTION;

DECLARE @id_client2 int = 2;

BEGIN TRY
    DELETE FROM Comenzi
    WHERE ID_client = @id_client2;

    DELETE FROM Clienti
    WHERE ID_client = @id_client2;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Tranzacția a fost anulată. A apărut o eroare: ' + ERROR_MESSAGE();
END CATCH
--Adaugarea unei noi categorii și actualizarea produselor care apartin de aceasta
BEGIN TRANSACTION;

DECLARE @nume_categorie varchar(60) = 'Accesorii';

BEGIN TRY
    INSERT INTO Categorii (nume_categorie)
    VALUES (@nume_categorie);

    DECLARE @id_categorie int = SCOPE_IDENTITY();

    UPDATE Produse
    SET categorieID = @id_categorie
    WHERE producatorID = 2;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT 'Tranzacția a fost anulată. A apărut o eroare: ' + ERROR_MESSAGE();
END CATCH



----Views

GO
--Vezi produsele care nu sunt in stoc.
CREATE VIEW ProduseOutOfStock
AS
SELECT nume_produs, descrier_produs, pret_produs, categorieID, producatorID
FROM Produse
WHERE stoc_produs = 0;
select* from ProduseOutOfStock

GO
--Vezi numele si pretul produselor care au rating mai mare sau egal cu 4.
CREATE VIEW ProduseCuRatingBun
AS
SELECT P.nume_produs, P.pret_produs
FROM Produse P
JOIN Recenzii R ON P.ID_produs = R.ID_produs
WHERE R.rating >= 4;
select * from ProduseCuRatingBun
GO
--Vezi numele si pretul produselor care au stocul mai mare sau egal cu 10
--si pretul mai mic sau egal cu 2000 de lei.
CREATE VIEW ProduseIeftineInStoc
AS
SELECT nume_produs, pret_produs
FROM Produse
WHERE stoc_produs >= 10 AND pret_produs <= 2000;
select * from ProduseIeftineInStoc
GO
--Vezi numele si pretul produselor produse de producatorii cu tara de provenienta Romania.
CREATE VIEW ProduseRomanesti
AS
SELECT P.nume_produs, P.pret_produs
FROM Produse P
JOIN Producatori PR ON P.producatorID = PR.ID_producator
WHERE PR.tara_producator = 'Romania';
select * from ProduseRomanesti
GO
--Vezi numele, adresa si numarul de telefon al clientilor care au plasat cel putin o comanda.
CREATE VIEW ClientiCuComenzi
AS
SELECT C.nume_client, C.adresa_client, C.telefon_client
FROM Clienti C
JOIN Comenzi CO ON C.ID_client = CO.ID_client;

select * from ClientiCuComenzi




GO
--Vezi numele și prețul produselor disponibile în stoc:
CREATE VIEW vw_ProduseDisponibile
AS
SELECT nume_produs, pret_produs
FROM Produse
WHERE stoc_produs > 0;
select * from vw_ProduseDisponibile
GO
--Vezi numele producătorilor care nu sunt din România:
CREATE VIEW vw_ProducatoriStraini
AS
SELECT nume_producator
FROM Producatori
WHERE tara_producator <> 'Romania';
select * from vw_ProducatoriStraini
GO
--Vezi numele categoriilor de produse și numărul de produse din fiecare categorie:
CREATE VIEW vw_CategoriiProduse
AS
SELECT c.nume_categorie, COUNT(*) AS numar_produse
FROM Produse p
INNER JOIN Categorii c ON p.categorieID = c.ID_categorie
GROUP BY c.nume_categorie;
select * from vw_CategoriiProduse
GO
--Vezi numele clienților și adresele lor:
CREATE VIEW vw_ClientiAdrese
AS
SELECT nume_client, adresa_client
FROM Clienti;
select * from vw_ClientiAdrese
GO
--Vezi numărul de comenzi plasate de fiecare client:
CREATE VIEW vw_NumarComenziClienti
AS
SELECT c.nume_client, COUNT(*) AS numar_comenzi
FROM Comenzi co
INNER JOIN Clienti c ON co.ID_client = c.ID_client
GROUP BY c.nume_client;
select * from vw_NumarComenziClienti
GO
--Vezi numele și prețul tuturor produselor din categoria "DJ":
CREATE VIEW vw_ProduseDJ
AS
SELECT nume_produs, pret_produs
FROM Produse
WHERE categorieID = (SELECT ID_categorie FROM Categorii WHERE nume_categorie = 'DJ');
select * from vw_ProduseDJ
GO
--Vezi numele și prețul tuturor produselor cu un preț mai mic de 3000 de lei:
CREATE VIEW vw_ProduseSub3000
AS
SELECT nume_produs, pret_produs
FROM Produse
WHERE pret_produs < 3000;
select * from vw_ProduseSub3000
GO
--Vezi numărul de produse disponibile pentru fiecare producător:
CREATE VIEW vw_NumarProduseProducator
AS
SELECT pr.nume_producator, COUNT(*) AS numar_produse
FROM Produse p
INNER JOIN Producatori pr ON p.producatorID = pr.ID_producator
WHERE p.stoc_produs > 0
GROUP BY pr.nume_producator;
select * from vw_NumarProduseProducator
GO
--Vezi numărul total de produse disponibile în stoc:
CREATE VIEW vw_NumarTotalProduseDisponibile
AS
SELECT SUM(stoc_produs) AS numar_total
FROM Produse;
select * from vw_NumarTotalProduseDisponibile
GO
--Vezi numărul total de transporturi efectuate de fiecare companie:
CREATE VIEW vw_NumarTransporturiCompanii
AS
SELECT ct.nume_companie, COUNT(*) AS numar_transporturi
FROM Transporturi t
INNER JOIN Companii_Transport ct ON t.ID_companie = ct.ID_companie
GROUP BY ct.nume_companie;

select * from vw_NumarTransporturiCompanii


GO
--View-ul "ProduseInStoc" va afișa numele, descrierea și prețul produselor care sunt în stoc.
CREATE VIEW ProduseInStoc AS
SELECT nume_produs,  pret_produs
FROM Produse
WHERE stoc_produs > 0;
select * from ProduseInStoc
GO
--View-ul "TopProduse" va afișa cele mai vândute produse,
--ordonate descrescător după numărul de bucăți vândute.
CREATE VIEW TopProduse AS
SELECT p.nume_produs, SUM(dc.cantitate) AS nr_buc_vandute
FROM Produse p
JOIN Detalii_Comenzi dc ON p.ID_produs = dc.ID_produs
GROUP BY p.nume_produs
select * from TopProduse
-----------ORDER BY nr_buc_vandute DESC;
GO
--View-ul "ComenziCuDetalii" va afișa toate comenzile și detaliile acestora.
CREATE VIEW ComenziCuDetalii AS
SELECT c.ID_comanda, c.data_comanda, c.status_comanda, cl.nume_client, cl.adresa_client, cl.telefon_client, cl.email_client,
       p.nume_produs, dc.cantitate, p.pret_produs
FROM Comenzi c
JOIN Clienti cl ON c.ID_client = cl.ID_client
JOIN Detalii_Comenzi dc ON c.ID_comanda = dc.ID_comanda
JOIN Produse p ON dc.ID_produs = p.ID_produs;
select * from ComenziCuDetalii

GO
--View-ul "RecenziiProduse" va afișa numele produselor,
--ratingul mediu și numărul total de recenzii primite de fiecare produs.
CREATE VIEW Recenzii_Produse AS
SELECT p.nume_produs, COUNT(r.ID_recenzie) AS nr_recenzii, AVG(r.rating) AS rating_mediu
FROM Produse p
LEFT JOIN Recenzii r ON p.ID_produs = r.ID_produs
GROUP BY p.nume_produs;
select * from Recenzii_Produse

GO
--View-ul "CompaniiTransport" va afișa toate companiile de transport disponibile și tarifele aferente.
CREATE VIEW CompaniiTransport AS
SELECT nume_companie, tarif_companie
FROM Companii_Transport;
select * from CompaniiTransport

--drop view CompaniiTransport
--drop view Recenzii_Produse
--drop view ComenziCuDetalii
--drop view TopProduse
--drop view ProduseInStoc


----Proceduri stocate

GO
--Adauga un nou produs in tabela Produse.
CREATE PROCEDURE AdaugaProdus
    @nume_produs varchar(50),
    @descriere_produs varchar(200),
    @pret_produs float,
    @stoc_produs int,
    @categorieID int,
    @producatorID int
AS
BEGIN
    INSERT INTO Produse (nume_produs, descrier_produs, pret_produs, stoc_produs, categorieID, producatorID)
    VALUES (@nume_produs, @descriere_produs, @pret_produs, @stoc_produs, @categorieID, @producatorID)
END

GO
--Actualizeaza informatiile unui produs existent in tabela Produse.
CREATE PROCEDURE ActualizeazaProdus
    @ID_produs int,
    @nume_produs varchar(50),
    @descriere_produs varchar(200),
    @pret_produs float,
    @stoc_produs int,
    @categorieID int,
    @producatorID int
AS
BEGIN
    UPDATE Produse
    SET nume_produs = @nume_produs,
        descrier_produs = @descriere_produs,
        pret_produs = @pret_produs,
        stoc_produs = @stoc_produs,
        categorieID = @categorieID,
        producatorID = @producatorID
    WHERE ID_produs = @ID_produs
END

GO
--Sterge un produs existent din tabela Produse si toate detaliile comenziilor asociate cu produsul.
CREATE PROCEDURE StergeProdus
    @ID_produs int
AS
BEGIN
    DELETE FROM Detalii_Comenzi
    WHERE ID_produs = @ID_produs
    
    DELETE FROM Produse
    WHERE ID_produs = @ID_produs
END

GO
--Adauga o noua comanda in tabela Comenzi.
CREATE PROCEDURE AdaugaComanda
    @data_comanda date,
    @ID_client int,
    @status_comanda varchar(30)
AS
BEGIN
    INSERT INTO Comenzi (data_comanda, ID_client, status_comanda)
    VALUES (@data_comanda, @ID_client, @status_comanda)
END

GO
--Sterge o comanda existenta din tabela Comenzi si toate detaliile comenziilor asociate cu comanda.
CREATE PROCEDURE StergeComanda
    @ID_comanda int
AS
BEGIN
    DELETE FROM Detalii_Comenzi
    WHERE ID_comanda = @ID_comanda
    
    DELETE FROM Transporturi
    WHERE ID_comanda = @ID_comanda
    
    DELETE FROM Comenzi
    WHERE ID_comanda = @ID_comanda
END

GO
--Adaugare producator
CREATE PROCEDURE AdaugaProducator
    @nume_producator varchar(50),
    @tara_producator varchar(50)
AS
BEGIN
    INSERT INTO Producatori (nume_producator, tara_producator)
    VALUES (@nume_producator, @tara_producator)
END


GO
--Adaugare client
CREATE PROCEDURE AdaugaClient
    @nume_client varchar(50),
    @adresa_client varchar(50),
    @telefon_client varchar(10),
    @email_client varchar(30)
AS
BEGIN
    INSERT INTO Clienti (nume_client, adresa_client, telefon_client, email_client)
    VALUES (@nume_client, @adresa_client, @telefon_client, @email_client)
END


Go
--Adaugare categorie
CREATE PROCEDURE AdaugaCategorie
    @nume_categorie varchar(60)
AS
BEGIN
    INSERT INTO Categorii (nume_categorie)
    VALUES (@nume_categorie)
END


GO
--Adaugare companie transport
CREATE PROCEDURE AdaugaCompanieTransport
    @nume_companie varchar(50),
    @tarif_companie int
AS
BEGIN
    INSERT INTO Companii_Transport (nume_companie, tarif_companie)
    VALUES (@nume_companie, @tarif_companie)
END


Go
--Adaugare transport
CREATE PROCEDURE AdaugaTransport
    @ID_comanda int,
    @ID_companie int,
    @data_livrare date
AS
BEGIN
    INSERT INTO Transporturi (ID_comanda, ID_companie, data_livrare)
    VALUES (@ID_comanda, @ID_companie, @data_livrare)
END

----Triggers
GO
--Trigger care verifica daca un produs are 0 stoc si trimite notificare
--la administrator
CREATE TRIGGER zero_stock_trigger
ON Produse
AFTER INSERT
AS
BEGIN
  IF EXISTS(SELECT * FROM inserted WHERE stoc_produs = 0)
  BEGIN
    EXEC msdb.dbo.sp_send_dbmail
      @profile_name='your_profile_name',
      @recipients='admin@yourcompany.com',
      @subject='Products with zero stock',
      @body='The following products have zero stock: ' 
        (SELECT STRING_AGG(nume_produs, ', ') FROM inserted WHERE stoc_produs = 0)
  END
END

GO
--Trigger care sa verifice	daca adresa de email a unui client e valida,
--si daca are domeniul @yahoo.com, daca nu trimite notificare
CREATE TRIGGER invalid_email_trigger
ON Clienti
AFTER INSERT
AS
BEGIN
  IF EXISTS(SELECT * FROM inserted WHERE email_client NOT LIKE '%@gmail.com')
  BEGIN
    EXEC msdb.dbo.sp_send_dbmail
      @profile_name='your_profile_name',
      @recipients='admin@yourcompany.com',
      @subject='Invalid email address',
      @body='The following client has an invalid email address: ' 
        (SELECT CONCAT(nume_client, ' (', email_client, ')') FROM inserted WHERE email_client NOT LIKE '%@yahoo.com')
  END
END
drop trigger invalid_email_trigger

select * from Comenzi
GO
--Trigger sa verifice daca statusul unei comenzi e 'in procesare',
--si plasata cu mai mult de 3 zile inainte, trimite notif la administrator
CREATE TRIGGER pending_order_trigger
ON Comenzi
AFTER INSERT
AS
BEGIN
  IF EXISTS(SELECT * FROM inserted WHERE status_comanda = 'in procesare' AND data_comanda < DATEADD(day, -3, GETDATE()))
  BEGIN
    EXEC msdb.dbo.sp_send_dbmail
      @profile_name='your_profile_name',
      @recipients='admin@yourcompany.com',
      @subject='Pending order',
      @body='The following order has been pending for more than 3 days: '
        (SELECT CONCAT(ID_comanda, ' (', data_comanda, ')') FROM inserted WHERE status_comanda = 'in procesare' AND data_comanda < DATEADD(day, -3, GETDATE()))
  END
END
drop trigger pending_order_trigger

--Trigger sa verifice daca un produs are rating mai mic sau egal cu 3
--daca da trimite notificare la administrator
GO
CREATE TRIGGER low_rating_trigger
ON Recenzii
AFTER INSERT
AS
BEGIN
  IF EXISTS(SELECT * FROM inserted WHERE rating < 3)
  BEGIN
    EXEC msdb.dbo.sp_send_dbmail
      @profile_name='your_profile_name',
      @recipients='admin@yourcompany.com',
      @subject='Low product rating',
      @body='The following product has received a low rating: ' 
        (SELECT CONCAT(i.ID_produs , ' (', nume_produs, ')') FROM inserted i JOIN Produse p ON i.ID_produs = p.ID_produs WHERE i.rating < 3)
  END
END
drop trigger low_rating_trigger



GO
--Trigger pentru adaugarea de produse:
CREATE TRIGGER trg_add_produs
ON Produse
AFTER INSERT
AS
BEGIN
    DECLARE @produsID INT;
    SET @produsID = (SELECT ID_produs FROM inserted);
    
    INSERT INTO Recenzii (ID_produs, ID_client, rating, comentariu)
    VALUES (@produsID, NULL, 0, NULL);
END
GO
--Trigger pentru stocul de produse:
CREATE TRIGGER trg_update_stoc
ON Detalii_Comenzi
AFTER INSERT, UPDATE
AS
BEGIN
    DECLARE @produsID INT;
    SET @produsID = (SELECT ID_produs FROM inserted);
    
    UPDATE Produse
    SET stoc_produs = stoc_produs - (SELECT cantitate FROM inserted WHERE ID_produs = @produsID)
    WHERE ID_produs = @produsID;
END
GO
--Trigger pentru stergerea de produse:
CREATE TRIGGER trg_delete_produs
ON Produse
AFTER DELETE
AS
BEGIN
    DECLARE @produsID INT;
    SET @produsID = (SELECT ID_produs FROM deleted);
    
    DELETE FROM Recenzii
    WHERE ID_produs = @produsID;
    
    DELETE FROM Detalii_Comenzi
    WHERE ID_produs = @produsID;
END
GO
--Trigger pentru statusul comenzilor:
CREATE TRIGGER trg_update_status_comanda
ON Comenzi
AFTER UPDATE
AS
BEGIN
    DECLARE @comandaID INT;
    SET @comandaID = (SELECT ID_comanda FROM inserted);
    
    DECLARE @status varchar(30);
    SET @status = (SELECT status_comanda FROM inserted);
    
    IF @status = 'livrata'
    BEGIN
        INSERT INTO Transporturi (ID_comanda, ID_companie, data_livrare)
        VALUES (@comandaID, (SELECT TOP 1 ID_companie FROM Companii_Transport ORDER BY tarif_companie ASC), GETDATE());
    END
END
GO
--Trigger pentru adaugarea de clienti:
CREATE TRIGGER trg_add_client
ON Clienti
AFTER INSERT
AS
BEGIN
    DECLARE @clientID INT;
    SET @clientID = (SELECT ID_client FROM inserted);
    
    INSERT INTO Comenzi (data_comanda, ID_client, status_comanda)
    VALUES (GETDATE(), @clientID, 'in asteptare');
END
GO
--Trigger pentru a actualiza stocul produselor atunci când se introduce o nouă comandă:
CREATE TRIGGER actualizare_stoc
ON Detalii_Comenzi
AFTER INSERT
AS
BEGIN
  UPDATE p
  SET p.stoc_produs = p.stoc_produs - i.cantitate
  FROM Produse p
  INNER JOIN inserted i ON i.ID_produs = p.ID_produs;
END
GO
--Trigger pentru a adăuga un nou producător implicit din România,
--atunci când este introdus un produs fără producător specificat:
CREATE TRIGGER adauga_producator
ON Produse
AFTER INSERT
AS
BEGIN
  IF NOT EXISTS (SELECT * FROM inserted WHERE producatorID IS NOT NULL)
  BEGIN
    DECLARE @producatorID INT
    INSERT INTO Producatori (nume_producator) VALUES ('Producător implicit')
    SET @producatorID = SCOPE_IDENTITY()
    UPDATE Produse SET producatorID = @producatorID WHERE ID_produs IN (SELECT ID_produs FROM inserted)
  END
END
GO
--Trigger pentru a preveni ștergerea unui client care are comenzi înregistrate:
CREATE TRIGGER sterge_client
ON Clienti
INSTEAD OF DELETE
AS
BEGIN
  IF EXISTS (SELECT * FROM Comenzi WHERE ID_client IN (SELECT ID_client FROM deleted))
  BEGIN
    RAISERROR ('Acest client are comenzi înregistrate și nu poate fi șters!', 16, 1)
  END
  ELSE
  BEGIN
    DELETE FROM Clienti WHERE ID_client IN (SELECT ID_client FROM deleted)
  END
END
GO
--Trigger pentru a actualiza data de livrare a transportului,
--atunci când se actualizează data de livrare a comenzii:
CREATE TRIGGER actualizare_data_livrare
ON Comenzi
AFTER UPDATE
AS
BEGIN
  UPDATE t
  SET t.data_livrare = i.data_comanda
  FROM Transporturi t
  INNER JOIN inserted i ON i.ID_comanda = t.ID_comanda;
END
GO
--Trigger pentru a adăuga o nouă categorie implicită,
--atunci când se introduce un produs fără categorie specificată:
CREATE TRIGGER adauga_categorie
ON Produse
AFTER INSERT
AS
BEGIN
  IF NOT EXISTS (SELECT * FROM inserted WHERE categorieID IS NOT NULL)
  BEGIN
    DECLARE @categorieID INT
    INSERT INTO Categorii (nume_categorie) VALUES ('Categorie implicită')
    SET @categorieID = SCOPE_IDENTITY()
    UPDATE Produse SET categorieID = @categorieID WHERE ID_produs IN (SELECT ID_produs FROM inserted)
  END
END

----DELETE's

--Stergere produse care nu mai sunt in stoc (au stoc_produs = 0):
DELETE FROM Produse
WHERE stoc_produs = 0;
--Stergere toate comenzile pentru care nu a fost inca setat un status:
DELETE FROM Comenzi
WHERE status_comanda IS NULL;
--Stergere recenzii cu rating mai mic de 3:
DELETE FROM Recenzii
WHERE rating < 3 
--Stergere clienti care nu au plasat nicio comanda:
DELETE FROM Clienti
WHERE ID_client NOT IN (SELECT DISTINCT ID_client FROM Comenzi);
--Stergere transporturi pentru care data_livrare este mai veche de 7 zile:
DELETE FROM Transporturi
WHERE DATEDIFF(DAY, data_livrare, GETDATE()) > 7;
select * from Transporturi

--Stergerea tuturor inregistrarilor din tabela "Recenzii":
DELETE FROM Recenzii;
--Stergerea inregistrarilor din tabela "Produse" cu pretul mai mic decat 2000:
DELETE FROM Produse
WHERE pret_produs < 2000;
--Stergerea inregistrarilor din tabela "Comenzi" care nu au niciun transport asociat:
DELETE FROM Comenzi
WHERE ID_comanda NOT IN (SELECT ID_comanda FROM Transporturi);
--Stergerea inregistrarilor din tabela "Clienti" cu numele "Popescu":
DELETE FROM Clienti
WHERE nume_client = 'Popescu';
--Stergerea inregistrarilor din tabela "Detalii_Comenzi" pentru produsul cu ID-ul 3:
DELETE FROM Detalii_Comenzi
WHERE ID_produs = 3;


--Șterge toate produsele dintr-o anumită categorie și de la un anumit producător:
DELETE p
FROM Produse p
JOIN Categorii c ON p.categorieID = c.ID_categorie
JOIN Producatori pr ON p.producatorID = pr.ID_producator
WHERE c.nume_categorie = 'DJ' AND pr.nume_producator = 'Pioneer';

--Șterge toate recenziile pentru un anumit produs și de la un anumit client:
DELETE r
FROM Recenzii r
JOIN Produse p ON r.ID_produs = p.ID_produs
JOIN Clienti c ON r.ID_client = c.ID_client
WHERE p.nume_produs = 'Pioneer DJ DDJ-400' AND c.nume_client = 'Popescu Ion';
select * from Produse
select * from Clienti

--Șterge toate detaliile comenzilor pentru o anumită comandă și pentru un anumit produs:
DELETE dc
FROM Detalii_Comenzi dc
JOIN Comenzi c ON dc.ID_comanda = c.ID_comanda
JOIN Produse p ON dc.ID_produs = p.ID_produs
WHERE c.ID_comanda = 1 AND p.nume_produs = 'Pioneer DJ DDJ-400';
select * from Detalii_Comenzi
--Șterge toate transporturile pentru o anumită companie de transport și pentru o anumită dată de livrare:
DELETE t
FROM Transporturi t
JOIN Companii_Transport ct ON t.ID_companie = ct.ID_companie
WHERE ct.nume_companie = 'DHL' AND t.data_livrare = '2023-05-03';

--Șterge toate produsele care au fost comandate de un anumit client
--și care au fost livrate de o anumită companie de transport:
DELETE p
FROM Produse p
JOIN Detalii_Comenzi dc ON p.ID_produs = dc.ID_produs
JOIN Comenzi c ON dc.ID_comanda = c.ID_comanda
JOIN Transporturi t ON c.ID_comanda = t.ID_comanda
JOIN Companii_Transport ct ON t.ID_companie = ct.ID_companie
WHERE c.ID_client = 1 AND ct.nume_companie = 'FedEx' AND t.data_livrare < GETDATE();

select * from Produse
EXECUTE AdaugaProdus @nume_produs='Pioneer DJ DDJ-10000-GT',@descriere_produs='Consola DJ',@pret_produs=11099,@stoc_produs=2,@categorieID=1,@producatorID=1;